export class APIError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

async function tryRefreshToken() {
  try {
    const response = await fetch(`${BASE_URL}/auth/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include',
    });
    
    if (!response.ok) return false;
    
    const data = await response.json();
    if (data.access_token) {
      localStorage.setItem('access_token', data.access_token);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

async function request(path, options = {}) {
  const token = localStorage.getItem('access_token');
  const fetchOptions = {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
    credentials: 'include',
  };

  // If uploading a file, don't set Content-Type to application/json
  if (options.body instanceof FormData) {
    delete fetchOptions.headers['Content-Type'];
  }

  let response = await fetch(`${BASE_URL}${path}`, fetchOptions);

  if (response.status === 401 && path !== '/auth/login' && path !== '/auth/refresh') {
    const refreshed = await tryRefreshToken();
    if (!refreshed) {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
      throw new APIError(401, 'Session expired');
    }
    
    // Retry with new token
    const newToken = localStorage.getItem('access_token');
    fetchOptions.headers['Authorization'] = `Bearer ${newToken}`;
    response = await fetch(`${BASE_URL}${path}`, fetchOptions);
  }

  if (!response.ok) {
    const errorBody = await response.json().catch(() => ({}));
    throw new APIError(response.status, errorBody.detail || errorBody.message || 'Unknown error');
  }

  return response.json();
}

export const api = {
  get: (path, options) => request(path, { ...options, method: 'GET' }),
  post: (path, body, options) => {
    return request(path, { 
      ...options, 
      method: 'POST', 
      body: body instanceof FormData ? body : JSON.stringify(body) 
    });
  },
  patch: (path, body, options) => {
    return request(path, { 
      ...options, 
      method: 'PATCH', 
      body: body instanceof FormData ? body : JSON.stringify(body) 
    });
  },
  delete: (path, options) => request(path, { ...options, method: 'DELETE' }),
};
