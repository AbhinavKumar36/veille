import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import { api } from './api/client.js'
import './index.css'

async function initApp() {
  try {
    const { access_token } = await api.post('/auth/refresh', {});
    localStorage.setItem('access_token', access_token);
    // Also mark auth as true for App.jsx state initialization
    localStorage.setItem('crimenet_auth', 'true');
  } catch (error) {
    localStorage.removeItem('access_token');
    localStorage.removeItem('crimenet_auth');
  }
  
  ReactDOM.createRoot(document.getElementById('root')).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  )
}

initApp();
